library(rentrez)
library(seqinr)
library(ggplot2)
library(dplyr)
library(tidyr)


omicron = read.fasta("O_BA.2.86.fasta",set.attributes = FALSE, strip.desc = TRUE,forceDNAtolower = FALSE)
alpha = read.fasta("A_B.1.1.7.fasta",set.attributes = FALSE, strip.desc = TRUE,forceDNAtolower = FALSE)
kappa = read.fasta("K_B.1.617.1.fasta",set.attributes = FALSE, strip.desc = TRUE,forceDNAtolower = FALSE)
eta = read.fasta("E_B.1.52.fasta",set.attributes = FALSE, strip.desc = TRUE,forceDNAtolower = FALSE)
epsilon = read.fasta("E_B.1.43.fasta",set.attributes = FALSE, strip.desc = TRUE,forceDNAtolower = FALSE)
delta = read.fasta("D_B.1.617.2.fasta",set.attributes = FALSE, strip.desc = TRUE,forceDNAtolower = FALSE)
beta = read.fasta("B_B.1.35.fasta",set.attributes = FALSE, strip.desc = TRUE,forceDNAtolower = FALSE)
mu = read.fasta("M_B.1.621.fasta",set.attributes = FALSE, strip.desc = TRUE,forceDNAtolower = FALSE)
zeta = read.fasta("Z_P.2.fasta",set.attributes = FALSE, strip.desc = TRUE,forceDNAtolower = FALSE)
theta = read.fasta("T_P.3.fasta",set.attributes = FALSE, strip.desc = TRUE,forceDNAtolower = FALSE)

tam = function(lista){
  tam = length(lista[[1]])
  print(tam)
  return(tam)
}

tamaño_omicron = tam(omicron)
tamaño_alpha = tam(alpha)
tamaño_kappa = tam(kappa)
tamaño_eta = tam(eta)
tamaño_epsilon = tam(epsilon)
tamaño_delta = tam(delta)
tamaño_beta = tam(beta)
tamaño_mu = tam(mu)
tamaño_zeta = tam(zeta)
tamaño_theta = tam(theta)

cuenta_nucleotidos = function(lista, n){
  nucleotidos = c("A", "G", "C", "T")
  resultados = numeric(4)
  for (i in 1:4){
    SUM = 0
    for (j in 1:n){
      if (lista[[1]][j] == nucleotidos[i]){
        SUM = SUM + 1
      }
    }
    resultados[i] = SUM 
    print(paste0(nucleotidos[i],": ", SUM))
  }
  return(resultados)
}


resultados_omicron = cuenta_nucleotidos(omicron, tamaño_omicron)
resultados_alpha = cuenta_nucleotidos(alpha, tamaño_alpha)
resultados_kappa = cuenta_nucleotidos(kappa, tamaño_kappa)
resultados_eta = cuenta_nucleotidos(eta, tamaño_eta)
resultados_epsilon = cuenta_nucleotidos(epsilon, tamaño_epsilon)
resultados_delta = cuenta_nucleotidos(delta, tamaño_delta)
resultados_beta = cuenta_nucleotidos(beta, tamaño_beta)
resultados_mu = cuenta_nucleotidos(mu, tamaño_mu)
resultados_zeta = cuenta_nucleotidos(zeta, tamaño_zeta)
resultados_theta = cuenta_nucleotidos(theta, tamaño_theta)

porcentaje_GC = function(lista, tam_lista){
  res = (lista[2]+lista[4])/(tam_lista)*100
  print(paste0("%GC: ", res))
  return(res)
}

GC_omicron = porcentaje_GC(resultados_omicron,tamaño_omicron)
GC_alpha = porcentaje_GC(resultados_alpha,tamaño_alpha)
GC_kappa = porcentaje_GC(resultados_kappa,tamaño_kappa)
GC_eta = porcentaje_GC(resultados_eta,tamaño_eta)
GC_epsilon = porcentaje_GC(resultados_epsilon,tamaño_epsilon)
GC_delta = porcentaje_GC(resultados_delta,tamaño_delta)
GC_beta = porcentaje_GC(resultados_beta,tamaño_beta)
GC_mu = porcentaje_GC(resultados_mu,tamaño_mu)
GC_zeta = porcentaje_GC(resultados_zeta,tamaño_zeta)
GC_theta = porcentaje_GC(resultados_theta,tamaño_theta)

directa_coplementaria = function(lista,n){
  directa_I = paste(unlist(head(lista[[1]],15)),collapse="")
  directa_F = paste(unlist(tail(lista[[1]],15)),collapse="")
  
  for(i in 1:n){
    if(lista[[1]][i] =="A"){
      lista[[1]][i] = "T"
    }
    else if(lista[[1]][i] =="T"){
      lista[[1]][i] = "A"
    }
    else if(lista[[1]][i] =="G"){
      lista[[1]][i] = "C"
    }
    else if(lista[[1]][i] =="C"){
      lista[[1]][i] = "G"
    }
  }
  comp_I = paste(unlist(head(lista[[1]],15)),collapse="")
  comp_F = paste(unlist(tail(lista[[1]],15)),collapse="")
  print(paste0("Complementaria: 3'-", comp_I, "...", comp_F, "-5'"))
  return(c(lista, directa_I,directa_F,comp_I,comp_F))
}

coplementaria_omicron = directa_coplementaria(omicron, tamaño_omicron)
coplementaria_alpha = directa_coplementaria(alpha, tamaño_alpha)
coplementaria_kappa = directa_coplementaria(kappa, tamaño_kappa)
coplementaria_eta = directa_coplementaria(eta, tamaño_eta)
coplementaria_epsilon = directa_coplementaria(epsilon, tamaño_epsilon)
coplementaria_delta = directa_coplementaria(delta, tamaño_delta)
coplementaria_beta = directa_coplementaria(beta, tamaño_beta)
coplementaria_mu = directa_coplementaria(mu, tamaño_mu)
coplementaria_zeta = directa_coplementaria(zeta, tamaño_zeta)
coplementaria_theta = directa_coplementaria(theta, tamaño_theta)



#gráficas virus
par(mar = c(1,1,1,1))
par(mfrow=c(2,1))
colores = c("blue","green","pink","purple")
barplot(resultados_omicron, col= colores)
title(main = "Omicron")
barplot(resultados_alpha, col= colores)
title(main = "Alpha")

par(mar = c(1,1,1,1))
par(mfrow=c(2,1))
colores = c("blue","green","pink","purple")
barplot(resultados_kappa, col= colores)
title(main = "Kappa")
barplot(resultados_eta, col= colores)
title(main = "Eta")

par(mar = c(1,1,1,1))
par(mfrow=c(2,1))
colores = c("blue","green","pink","purple")
barplot(resultados_epsilon, col= colores)
title(main = "Epsilon" )
barplot(resultados_delta, col= colores)
title(main = "Delta" )

par(mar = c(1,1,1,1))
par(mfrow=c(2,1))
colores = c("blue","green","pink","purple")
barplot(resultados_beta, col= colores)
title(main = "Beta" )
barplot(resultados_mu, col= colores)
title(main = "Mu" )

par(mar = c(1,1,1,1))
par(mfrow=c(2,1))
colores = c("blue","green","pink","purple")
barplot(resultados_zeta, col= colores)
title(main = "Zeta" )
barplot(resultados_theta, col= colores)
title(main = "Theta" )

